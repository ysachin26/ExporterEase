import type { Metadata } from 'next'
import './globals.css'
import { Toaster } from '@/components/ui/toaster'
import { LanguageProvider } from '@/contexts/LanguageContext'

export const metadata: Metadata = {
  title: 'GoFarmlyConnect - Transform Your Export Business',
  description: 'Complete export registration platform for GST, IEC, DSC, ICEGATE, and AD Code. Streamline your export business with expert guidance and digital solutions.',
  generator: 'v0.dev',
  viewport: 'width=device-width, initial-scale=1, shrink-to-fit=no',
  keywords: 'export registration, GST, IEC, DSC, ICEGATE, AD Code, export business, trade, agriculture',
  authors: [{ name: 'GoFarmlyConnect' }],
  robots: 'index, follow',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="scroll-smooth">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="theme-color" content="#10b981" />
      </head>
      <body className="antialiased">
        <LanguageProvider>
          {children}
          <Toaster />
        </LanguageProvider>
      </body>
    </html>
  )
}
